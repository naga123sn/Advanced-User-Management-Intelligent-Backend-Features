import API from "./api";


export const getStats = () => API.get("/stats");
export const getAnalytics = () => API.get("/analytics/dashboard");